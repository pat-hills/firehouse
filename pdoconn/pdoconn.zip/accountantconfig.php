<?php
//session_start();
define('conStringaccountant', 'mysql:host=localhost;dbname=knusbows_gmt');
define('dbUseraccountant', 'knusbows_marshall');
define('dbPassaccountant', ',.nIS%V-Py]M');


// define('conStringaccountant', 'mysql:host=localhost;dbname=group_assoc_db');
// define('dbUseraccountant', 'grup_asoc');
// define('dbPassaccountant', 'group_assoc_db_#2019');

 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$accountant = new Accountant();
$accountant->dbConnect(conStringaccountant, dbUseraccountant, dbPassaccountant);

 

 