<?php
//session_start();
define('conStringsecretary', 'mysql:host=localhost;dbname=knusbows_gmt');
define('dbUsersecretary', 'knusbows_marshall');
define('dbPasssecretary', ',.nIS%V-Py]M');

 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$secretary = new Secretary();
$secretary->dbConnect(conStringsecretary, dbUsersecretary, dbPasssecretary);

 

 